# camera_switcher

Blender addon for looping through cameras in a scene with a `Shift + Num 0` shortcut.
